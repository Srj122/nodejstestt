/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "i.ibb.co",
      },
      {
        protocol: "https",
        hostname: "images.unsplash.com",
      },
      {
        protocol: "http",
        hostname: "res.cloudinary.com",
        port: "",
        pathname: "/djlpbc9dz/image/upload/**",
      },
      {
        protocol: "https",
        hostname: "www.onlinecoursehow.com",
      },
      {
        protocol: "https",
        hostname: "miro.medium.com",
      },
      {
        protocol: "https",
        hostname: "sjcc.ac.in",
      },
      {
        protocol: "https",
        hostname: "sjcc.ac.in",
      },
      {
        protocol: "https",
        hostname: "www.reliablesoft.net",
      },
      {
        protocol: "https",
        hostname: "blogassets.leverageedu.com",
      },
    ],
  },
};

module.exports = nextConfig;
