import { FAQ, Hero, PopularCourses, UpComingEvents } from "@/components/Home";

const Home = () => (
  <>
    <Hero />
    <div className="bg-white pt-96 md:pt-40" />
    <UpComingEvents />
    <PopularCourses />
    <FAQ />
  </>
);

export default Home;
