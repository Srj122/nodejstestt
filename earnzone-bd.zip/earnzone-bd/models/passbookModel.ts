import { IPassbookSchema } from "@/interface";
import { Schema, model, models } from "mongoose";

const PassbookSchema = new Schema<IPassbookSchema>(
  {
    userId: {
      type: String,
      required: true,
    },
    studentId: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
    toJSON: {
      virtuals: true,
    },
  }
);

export const Passbook =
  models?.Passbook || model<IPassbookSchema>("Passbook", PassbookSchema);
