"use client";

import { NextPage } from "next";
import { useEffect, useState } from "react";

import { Header } from "@/components";
import { updateData, useCurrentUser } from "@/hooks";
import { INavItem } from "@/interface";
import { avatarProfile, uploadImg } from "@/lib";
import { BackButton, Button, Container } from "@/universal";
import { getFileUploader } from "@/utils/actions/getFileUploade";
import Image from "next/image";
import { AiOutlineHome } from "react-icons/ai";
import { toast } from "react-toastify";

const navData: INavItem[] = [
  {
    label: <BackButton className="text-2xl" />,
    link: "/tl/profile",
  },
  {
    label: <AiOutlineHome className="text-2xl" />,
    link: "/tl",
  },
];

const Edit: NextPage = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedFileThumb, setSelectedFileThumb] = useState<string | null>(
    null
  );
  const [disabled, setDisabled] = useState(true);
  const user = useCurrentUser(true);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    event.preventDefault();
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);

      const reader = new FileReader();

      reader.onload = (event) => {
        setSelectedFileThumb(event.target?.result as string);
      };

      reader.readAsDataURL(file);
    } else {
      toast.error("Invalid file type. Please choose a valid file.");
    }
  };

  useEffect(() => {
    selectedFile && setDisabled(false);
  }, [selectedFile]);

  const updateProfile = async () => {
    if (selectedFile) {
      const uploadedFile = await getFileUploader(selectedFile);
      if (uploadedFile) {
        updateData("/user", { image: uploadedFile }).then(() =>
          window.location.reload()
        );
      }
    }
  };

  return (
    <main>
      <Header navData={navData} />

      <Container className="flex flex-col justify-center items-center">
        <h1 className="text-4xl font-semibold my-10 text-center">
          Edit Profile
        </h1>
        <div className="flex flex-col justify-center items-center gap-2.5">
          {user?.image && (
            <Image
              src={user.image || avatarProfile}
              width={160}
              height={160}
              alt={user.firstName || ""}
              className="w-40 h-40 rounded-full"
            />
          )}

          <div className="flex justify-between px-4 pt-6">
            <label htmlFor="filePicker">
              <div className="flex items-center gap-2 cursor-pointer">
                {selectedFileThumb ? (
                  <Image
                    src={selectedFileThumb}
                    width={50}
                    height={50}
                    className="w-20 h-20 rounded ml-2"
                    alt="file uploading"
                  />
                ) : (
                  <Image
                    src={uploadImg}
                    className="w-20 h-20"
                    alt="file uploading"
                  />
                )}
                <p className="text-gray-500 font-medium">Change Photo</p>
              </div>
              <input
                type="file"
                name="filePicker"
                id="filePicker"
                accept="image/*"
                onChange={handleFileChange}
                hidden
              />
            </label>
          </div>

          <Button
            variant="secondary"
            className="capitalize mt-5 disabled:bg-opacity-50 disabled:cursor-not-allowed"
            onClick={updateProfile}
            disabled={disabled}
          >
            update profile
          </Button>
        </div>
      </Container>
    </main>
  );
};

export default Edit;
