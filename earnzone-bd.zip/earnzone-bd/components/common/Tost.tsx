"use client";

import { ITost } from "@/interface";
import { bell } from "@/lib/assets";
import { Button, CommonText } from "@/universal";
import Image from "next/image";
import { FC } from "react";

export const Tost: FC<ITost> = ({ label, btnText, onClick }) => (
  <div className="flex justify-between items-center gap-2.5 bg-green-200 w-full mx-auto mt-1.5 shadow-md rounded-md overflow-hidden py-0.5 px-1">
    <figure className="bg-white px-3.5 rounded-md overflow-hidden">
      <Image src={bell} alt="" className="w-10 h-10" />
    </figure>
    <CommonText className="capitalize">{label}</CommonText>
    {btnText && (
      <Button variant="secondary" onClick={onClick}>
        {btnText}
      </Button>
    )}
  </div>
);
