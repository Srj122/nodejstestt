import course1 from "./course1.jpeg";
import course2 from "./course2.jpg";
import course3 from "./course3.jpg";
import course4 from "./course4.jpg";
import course5 from "./course5.jpg";
import course6 from "./course6.jpg";
import course7 from "./course7.jpg";
import course8 from "./course8.jpg";
import course9 from "./course9.jpg";
import course10 from "./course10.jpg";

export {
  course1,
  course2,
  course3,
  course4,
  course5,
  course6,
  course7,
  course8,
  course9,
  course10,
};
