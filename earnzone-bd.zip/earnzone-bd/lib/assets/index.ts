import banner from "./banner.png";
import banner1 from "./banner1.jpg";
import banner2 from "./banner2.jpg";
import banner3 from "./banner3.jpg";
import banner4 from "./banner4.jpg";
import how2buy from "./how2buy.png";
import loginBanner from "./login-banner.jpg";
import meetingilustration from "./shape-2.png";

export * from "./card";
export * from "./icons";
export * from "./img";
export * from "./logo";

export {
  banner,
  banner1,
  banner2,
  banner3,
  banner4,
  how2buy,
  loginBanner,
  meetingilustration,
};
