"use client";

import { updateData } from "@/hooks";
import { Button } from "@/universal";
import { FC, useState } from "react";

export const ChangeFee: FC<{
  currentFee: number;
  fee: "Base" | "Withdrawal";
}> = ({ currentFee, fee }) => {
  const [prvFee, setPrvFee] = useState(currentFee | 0);
  const [newFee, setNewFee] = useState(currentFee | 0);

  const updateConfig = () => {
    const data =
      fee === "Base" ? { baseFee: newFee } : { withdrawalFee: newFee };
    updateData("/config", data);
    setPrvFee(newFee);
  };

  return (
    <div className="flex items-end justify-center w-full">
      <div className="flex flex-col gap-1">
        <label className="pl-1.5">
          {fee} Fee:
          <span className="font-bold">{prvFee}</span>
        </label>
        <div className="flex gap-2.5">
          <input
            type="number"
            onChange={(e) => setNewFee(Number(e.target.value))}
            value={newFee}
            className="outline-none text-black text-base md:text-lg max-w-xs border border-primary rounded-[5px] py-1 px-2"
          />
          <Button
            variant="secondary"
            className="py-[7px] lg:py-2.5 px-3"
            onClick={updateConfig}
          >
            Save
          </Button>
        </div>
      </div>
    </div>
  );
};
