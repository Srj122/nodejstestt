"use client";

import { FC } from "react";

export const About: FC = () => (
  <div className="bg-white pt-20">
    <p className="text-xl lg:text-4xl text-center w-full max-w-6xl mx-auto mt-14 mb-4">
      The Main objective of this setup is how to develop Skill&rsquo;s on
      digital marketing And how to generate revenue on it
    </p>
  </div>
);
