import { connectDb } from "@/config";
import { UserRole } from "@/lib";
import { AppConfig, Passbook, User } from "@/models";
import { ApiResponse } from "@/utils";
import getCurrentUser from "@/utils/actions/getCurrentUser";
import { NextRequest } from "next/server";

connectDb();

export const PATCH = async (req: NextRequest) => {
  try {
    const { userId, refId } = await req.json();

    // Get Current User
    const user = await getCurrentUser();

    if (!user) {
      return ApiResponse(404, "User not found❗");
    } else if (!user.role) {
      return ApiResponse(401, "Denied❗ unauthorized user 😠😡😠");
    }

    const appConfig = await AppConfig.findOne({ for: UserRole.admin }).select({
      baseFee: 1,
    });
    const baseFee = await appConfig.baseFee;

    // Referer get 150
    await User.updateOne(
      { userId: refId },
      { $inc: { balance: 150 } },
      { new: true }
    );

    const refUserId = await User.findOne({ userId: refId });

    // Team leaders get 60
    await User.updateOne(
      { userId: refUserId.settings.tl },
      { $inc: { balance: 60 } },
      { new: true }
    );

    // Trainer get 50
    await User.updateOne(
      { userId: refUserId.settings.trainer },
      { $inc: { balance: 50 } },
      { new: true }
    );

    // Senior Team Leaders get 20
    const refTlUser = await User.findOne({ userId: refUserId.settings.tl });
    await User.updateOne(
      { userId: refTlUser.settings.stl },
      { $inc: { balance: 20 } },
      { new: true }
    );

    const refUser = await User.findOne({ _id: userId }).select({
      userId: 1,
      firstName: 1,
      lastName: 1,
    });

    const passbookData = {
      userId: refId,
      studentId: refUser.userId,
      name: `${refUser.firstName} ${refUser.lastName}`,
      description: `You get 150 Tk bonus for one active user on your reference`,
      amount: 150,
    };

    await Passbook.create(passbookData);

    // Referer base fee status change
    await User.updateOne(
      { _id: userId },
      { "settings.activeBonus": true },
      { new: true }
    );
    // This will reduce the main company balance by 150
    const balanceIncrease = baseFee - 150;
    await AppConfig.updateOne(
      {},
      { $inc: { mainBalance: balanceIncrease } },
      { new: true }
    );

    return ApiResponse(200, "Add Active Bonus successfully ✅", {});
  } catch (error: any) {
    return ApiResponse(400, error.message);
  }
};
