import { UserRole } from "@/lib";
import { AppConfig, Passbook, User } from "@/models";
import { ApiResponse } from "@/utils";
import getCurrentUser from "@/utils/actions/getCurrentUser";

export const GET = async () => {
  try {
    // Get Current User
    const user = await getCurrentUser();

    if (!user) {
      return ApiResponse(404, "User not found❗");
    }

    const result = await User.find({ role: UserRole.active });

    return ApiResponse(200, "Active User get successfully 👌", result);
  } catch (error: any) {
    return ApiResponse(400, error.message);
  }
};

// Use this method to activate inactive user
export const PATCH = async () => {
  try {
    // Get Current User
    const user = await getCurrentUser();

    if (!user) {
      return ApiResponse(404, "User not found❗");
    } else if (user.role !== UserRole.inactive) {
      return ApiResponse(404, "User already activated❗");
    }

    const appConfig = await AppConfig.findOne({}).select({ baseFee: 1 });
    const baseFee = Number(await appConfig.baseFee);

    if (user.reference !== "-") {
      // Referer get 150
      await User.updateOne(
        { userId: user.reference },
        { $inc: { balance: 150 } },
        { new: true }
      );

      const refUser = await User.findOne({ userId: user.reference });

      // Team leaders get 60
      await User.updateOne(
        { userId: refUser.settings.tl },
        { $inc: { balance: 60 } },
        { new: true }
      );

      // Trainer get 50
      await User.updateOne(
        { userId: refUser.settings.trainer },
        { $inc: { balance: 50 } },
        { new: true }
      );

      // Senior Team Leaders get 20
      const refTlUser = await User.findOne({ userId: refUser.settings.tl });
      await User.updateOne(
        { userId: refTlUser.settings.stl },
        { $inc: { balance: 20 } },
        { new: true }
      );

      const passbookData = {
        userId: user.reference,
        studentId: user.userId,
        name: `${user.firstName} ${user.lastName}`,
        description: `You get 150 Tk bonus for one active user on your reference.`,
        amount: 150,
      };

      await Passbook.create(passbookData);
    }

    // Referer base fee status change, change balance, add activation bonus and user role = active
    const passbookData = {
      userId: user.userId,
      studentId: "My Account",
      name: `${user.firstName} ${user.lastName}`,
      description: `Your account has been charged a 500 Taka activation fee.`,
      amount: 500,
    };

    await Passbook.create(passbookData);

    const passbookData2 = {
      userId: user.userId,
      studentId: "My Account",
      name: `${user.firstName} ${user.lastName}`,
      description: `Congratulation, you have got 200 Tk bonus for your ID activation.`,
      amount: 200,
    };

    await Passbook.create(passbookData2);

    const newUserBalance = baseFee - 200;

    await User.updateOne(
      { _id: user.id },
      {
        "settings.activates": new Date(),
        "settings.activeBonus": true,
        role: UserRole.active,
        $inc: { balance: -newUserBalance },
      },
      { new: true }
    );

    // This will reduce the main company balance by 150
    await AppConfig.updateOne(
      {},
      { $inc: { mainBalance: -150 } },
      { new: true }
    );

    return ApiResponse(200, "Add Active Bonus successfully ✅", {});
  } catch (error: any) {
    return ApiResponse(400, error.message);
  }
};
