import { NextRequestWithAuth, withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";
import { UserRole } from "./lib";

export default withAuth(
  function middleware(request: NextRequestWithAuth) {
    const { token } = request.nextauth;
    const { pathname } = request.nextUrl;

    if (!token) {
      // User is not logged in, redirect to home page
      return NextResponse.redirect("/");
    }

    const userRole = token.role;

    if (
      userRole === UserRole.active &&
      !pathname.startsWith("/active") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/active", request.url));
    } else if (
      userRole === UserRole.inactive &&
      !pathname.startsWith("/inactive") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/inactive", request.url));
    } else if (
      userRole === UserRole.admin &&
      !pathname.startsWith("/admin") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/admin", request.url));
    } else if (
      userRole === UserRole.teacher &&
      !pathname.startsWith("/teacher") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/teacher", request.url));
    } else if (
      userRole === UserRole.checker &&
      !pathname.startsWith("/checker") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/checker", request.url));
    } else if (
      userRole === UserRole.controller &&
      !pathname.startsWith("/controller") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/controller", request.url));
    } else if (
      userRole === UserRole.consultant &&
      !pathname.startsWith("/consultant") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/stl", request.url));
    } else if (
      userRole === UserRole.stl &&
      !pathname.startsWith("/stl") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/stl", request.url));
    } else if (
      userRole === UserRole.tl &&
      !pathname.startsWith("/tl") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/tl", request.url));
    } else if (
      userRole === UserRole.trainer &&
      !pathname.startsWith("/trainer") &&
      !pathname.startsWith("/photo-zone") &&
      !pathname.startsWith("/forgot-password")
    ) {
      return NextResponse.redirect(new URL("/trainer", request.url));
    }
  },
  {
    callbacks: {
      authorized: ({ token }) => {
        return !!token;
      },
    },
  }
);

export const config = {
  matcher: [
    "/active",
    "/active/change-password",
    "/active/courses",
    "/active/my-ref",
    "/active/passbook",
    "/active/ref-list",
    "/active/user",
    "/active/user/[slug]",
    "/active/user/profile",
    "/active/user/profile/edit",
    "/active/user/withdrawal",
    "/active/photo-zone",
    "/admin",
    "/admin/action",
    "/admin/balance",
    "/admin/reports",
    "/admin/settings",
    "/admin/user-management",
    "/admin/user-management/count",
    "/admin/user-management/ref-list",
    "/admin/user-management/ref-list/my-ref",
    "/admin/user-management/send-wish",
    "/admin/user-management/stl",
    "/admin/user-management/stl/request",
    "/admin/user-management/tl",
    "/admin/user-management/tl/request",
    "/admin/user-management/trainer",
    "/admin/user-management/trainer/request",
    "/admin/user-management/student",
    "/inactive",
    "/inactive/profile",
    "/photo-zone",
    "/photo-zone/profile",
    "/photo-zone/user-profile/[slug]",
    "/teacher",
    "/teacher/change-password",
    "/teacher/profile",
    "/teacher/profile/edit",
    "/checker",
    "/checker/change-password",
    "/checker/profile",
    "/checker/profile/edit",
    "/controller",
    "/controller/change-password",
    "/controller/profile",
    "/controller/profile/edit",
    "/consultant",
    "/consultant/count",
    "/consultant/change-password",
    "/consultant/profile",
    "/consultant/profile/edit",
    "/stl",
    "/stl/inactive",
    "/stl/count",
    "/stl/change-password",
    "/stl/profile",
    "/stl/profile/edit",
    "/tl",
    "/tl/count",
    "/tl/trainer",
    "/tl/inactive",
    "/tl/change-password",
    "/tl/profile",
    "/tl/profile/edit",
    "/trainer",
    "/trainer/count",
    "/trainer/inactive",
    "/trainer/change-password",
    "/trainer/profile",
    "/trainer/profile/edit",
    "/forgot-password",
  ],
};
