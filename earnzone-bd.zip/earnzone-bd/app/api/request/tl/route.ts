import { UserRole } from "@/lib";
import { Request } from "@/models";
import { ApiResponse } from "@/utils";
import getCurrentUser from "@/utils/actions/getCurrentUser";

export const GET = async () => {
  try {
    // Get Current User
    const user = await getCurrentUser();

    if (!user) {
      return ApiResponse(404, "User not found❗");
    } else if (user.role !== UserRole.admin) {
      return ApiResponse(401, "Denied❗ unauthorized user 😠😡😠");
    }

    const result = await Request.find({ to: user.userId, requestBy: "tl" });

    return ApiResponse(200, "Request Get successfully 👌", result);
  } catch (error: any) {
    return ApiResponse(400, error.message);
  }
};
