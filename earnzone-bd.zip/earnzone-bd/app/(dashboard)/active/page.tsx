"use client";

import { useEffect, useState } from "react";
import { toast } from "react-toastify";

import { CompanyName, Header, Slider, TostContainer } from "@/components";
import {
  HelpLink,
  LiveLearningClass,
  MeetingLink,
  SupportTeam,
} from "@/components/User/Active";
import { updateData, useCurrentUser, useGetData } from "@/hooks";
import { IAppConfig, INavItem, ISlider } from "@/interface";
import { Button, CommonText, Container, Title } from "@/universal";
import { NextPage } from "next";
import Link from "next/link";
import { AiOutlineHome } from "react-icons/ai";

const navData: INavItem[] = [
  {
    label: <AiOutlineHome className="text-2xl" />,
    link: "/active",
  },
  {
    label: "Profile",
    link: "/active/user/profile",
  },
  {
    label: "Courses",
    link: "/active/courses",
  },
  {
    label: "References",
    link: "/active/ref-list",
  },
  {
    label: "Photo Zone",
    link: "/photo-zone",
  },
];

const Active: NextPage = () => {
  const [config, setConfig] = useState<IAppConfig | null>(null);
  const [sliders, setSliders] = useState<ISlider[]>([]);
  const user = useCurrentUser(true);

  useGetData("/config", setConfig);
  useGetData("/config/slider", setSliders, true);

  useEffect(() => {
    if (user?.settings.activeNotice) {
      toast.info("You are an active Seller 🏅, well done!✅", {
        autoClose: 5000,
      });
      toast.warn(
        "Don't share your personal information with anyone even our employees and Student's and Seller and also don't share your personal information on any post Like phone number password and any kind of OTP.",
        {
          autoClose: 15000,
          delay: 5000,
          theme: "colored",
        }
      );
      toast("🎥 Any kind of problem join here for solution", {
        autoClose: 10000,
        delay: 20000,
      });
      updateData("/user", { "settings.activeNotice": false }, true);
    }
  }, [user?.settings.activeNotice]);

  return (
    <main className="pb-10">
      <Header navData={navData} />
      <TostContainer />
      <div className="max-w-lg w-full mx-auto py-6 flex flex-col justify-center">
        <Title variant="H3" className="capitalize">
          Welcome To <CompanyName />
        </Title>

        {sliders && sliders?.length !== 0 && <Slider slides={sliders} />}
      </div>
      <Container className="flex flex-col-reverse lg:flex-row justify-center items-center gap-10 w-full pt-12 px-6 mx-auto">
        <div className="space-y-5">
          <HelpLink meetId={config?.support.help || ""} />
          <MeetingLink
            meetId={config?.support.meeting || ""}
            title="earnzone-bd Support Meeting"
          />
        </div>
        <SupportTeam label={config?.support.whatsApp || ""} />
      </Container>
      <Container className="my-8">
        <div className="w-full max-w-sm mx-auto bg-slate-50 shadow-2xl p-1.5 rounded">
          <p className="text-center text-sm text-white font-semibold w-full bg-secondary p-2 rounded capitalize">
            earnzone-bd join live learning Training class Bangladesh Time(8:00
            AM to 10:00 PM)
          </p>
        </div>
      </Container>
      <Container className="w-full max-w-2xl grid grid-cols-1 md:grid-cols-2 gap-5 justify-items-center">
        <LiveLearningClass />
      </Container>
      <Container className="pt-10 flex-col justify-center items-center text-center w-fit">
        <Title variant="H4" className="capitalize pt-5">
          Earnzone-bd support
        </Title>
        <CommonText className="pt-2.5 px-2.5">
          Any Kind of Problem join here for Solution&nbsp;
          <Link href="/" className="text-sky-500">
            earnzone-bd.com
          </Link>
        </CommonText>

        <Button variant="primary" className="py-2.5 w-full mt-2.5">
          WhatsApp
        </Button>
      </Container>
    </main>
  );
};

export default Active;
