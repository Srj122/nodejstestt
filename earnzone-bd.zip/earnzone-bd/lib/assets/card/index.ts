import course1 from "./course/courses1.jpeg";
import course2 from "./course/courses6.jpeg";
import course3 from "./course/lead_generaation.jpg";

import serviceImg1 from "./service/image1.jpg";
import serviceImg2 from "./service/image2.jpg";

export { course1, course2, course3, serviceImg1, serviceImg2 };
