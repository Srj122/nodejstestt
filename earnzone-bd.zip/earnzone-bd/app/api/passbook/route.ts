import { Passbook, User } from "@/models";
import { ApiResponse } from "@/utils";
import getCurrentUser from "@/utils/actions/getCurrentUser";
import { NextRequest } from "next/server";

export const POST = async (req: NextRequest) => {
  try {
    const { user_id, amount, description } = await req.json();
    // Get Current User
    const user = await getCurrentUser();

    if (!user) {
      return ApiResponse(404, "User not found❗");
    }

    const studentId = await User.findOne({ _id: user_id });

    const passbookData = {
      userId: studentId.userId,
      studentId: "My Account",
      name: `${user.firstName} ${user.lastName}`,
      description: `Congratulation, you have got 200 Tk bonus for your ID activation.`,
      amount: 200,
    };

    const result = await Passbook.create(passbookData);

    return ApiResponse(200, "Passbook add successfully 👌", result);
  } catch (error: any) {
    return ApiResponse(400, error.message);
  }
};

export const GET = async () => {
  try {
    // Get Current User
    const user = await getCurrentUser();

    if (!user) {
      return ApiResponse(404, "User not found❗");
    }

    const result = await Passbook.find({ userId: user.userId }).sort({
      createdAt: -1,
    });

    return ApiResponse(200, "Active User get successfully 👌", result);
  } catch (error: any) {
    return ApiResponse(400, error.message);
  }
};
