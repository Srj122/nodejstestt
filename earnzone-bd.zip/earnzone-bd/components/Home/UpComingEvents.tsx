"use client";

import { eventsData } from "@/lib/data";
import { CommonText, Container, Title } from "@/universal";
import { FC } from "react";
import { CompanyName } from "..";

export const UpComingEvents: FC = () => (
  <div className="bg-[#442e9e] w-full">
    <Container className="text-white text-center flex flex-col justify-center items-center gap-5 lg:gap-8 py-10 lg:py-20">
      <div className="space-y-2.5 max-w-lg">
        <Title variant="H2" className="text-3xl md:text-4xl capitalize">
          Upcoming occasions
        </Title>
        <CommonText className="text-white">
          Experience the corporate ambiance and supportive digital marketing
          community provided by <CompanyName /> Platform.
        </CommonText>
      </div>
      <div className="space-y-2.5">
        {eventsData.map(({ date, title }, idx) => (
          <div
            key={idx}
            className="w-full max-w-[550px] rounded-2xl border border-secondary grid grid-cols-4 py-5 items-center shadow-3xl px-2.5"
          >
            <p className="w-full text-2xl lg:text-3xl font-bold col-span-1 flex justify-center items-center text-center">
              <span className="border-2 rounded-full p-2.5 shadow-inner border-[#412d9b] shadow-[#0b0e4a]">
                {date}
              </span>
            </p>
            <p className="text-base md:text-lg font-poppins text-start col-span-3">
              {title}
            </p>
          </div>
        ))}
      </div>
    </Container>
  </div>
);
