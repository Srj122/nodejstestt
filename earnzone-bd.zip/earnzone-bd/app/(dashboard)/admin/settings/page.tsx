"use client";

import { Header } from "@/components";
import {
  ChangeFee,
  ChangeHelpLink,
  ChangeSupportLink,
} from "@/components/Settings";
import { useCurrentUser, useGetData } from "@/hooks";
import { IAppConfig, INavItem } from "@/interface";
import { UserRole } from "@/lib";
import { BackButton, Container, Title } from "@/universal";
import { NextPage } from "next";
import { useState } from "react";

const adminNav: INavItem[] = [
  {
    label: <BackButton className="text-2xl" />,
    link: "/admin",
  },
];

const Settings: NextPage = () => {
  const [config, setConfig] = useState<IAppConfig>();
  const user = useCurrentUser(true);
  useGetData("/config", setConfig, true);

  return (
    <main>
      <Header navData={adminNav} />

      <Title variant="H2" className="py-8 capitalize">
        Settings
      </Title>
      <Container>
        {user?.role === UserRole.admin && (
          <div className="flex flex-col gap-5 w-96 justify-center items-center mx-auto">
            <ChangeFee fee="Base" currentFee={config ? config.baseFee : 0} />
            <ChangeFee
              fee="Withdrawal"
              currentFee={config ? config.withdrawalFee : 0}
            />
            <ChangeSupportLink
              meeting={config ? config?.support?.meeting : ""}
              whatsApp={config ? config?.support?.whatsApp : ""}
            />
            <ChangeHelpLink help={config ? config?.support?.help : ""} />
          </div>
        )}
      </Container>
    </main>
  );
};

export default Settings;
