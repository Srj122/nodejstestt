import { IId } from ".";

export interface IPassbookSchema {
  userId: string;
  studentId: string;
  name: string;
  description: string;
  amount: number;
}

export interface IPassbook extends IPassbookSchema, IId {}
