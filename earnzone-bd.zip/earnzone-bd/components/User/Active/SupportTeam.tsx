"use client";

import { useGetData } from "@/hooks";
import { ILabel, ITlTrainer } from "@/interface";
import { FC, useState } from "react";
import { ActivePageCard, DataRow } from ".";

export const SupportTeam: FC<ILabel> = ({ label }) => {
  const [data, setData] = useState<ITlTrainer>();
  useGetData("/config/support", setData, true);

  return (
    <ActivePageCard title="earnzone-bd Support Team">
      <DataRow
        title="My Team Leader"
        phoneNo={data?.tl?.phone}
        btnText="WhatsApp"
      />
      <DataRow
        title="My Trainer"
        phoneNo={data?.trainer?.phone}
        btnText="WhatsApp"
      />

      <DataRow
        title="Support WhatsApp Group"
        groupLink={label}
        btnText="Join"
      />
    </ActivePageCard>
  );
};
