import { IId } from ".";

export interface IRequestSchema {
  to: string;
  userId: string;
  seniorId: string;
  requestBy: "stl" | "tl" | "trainer" | "consultant";
}

export interface IRequest extends IRequestSchema, IId {}
