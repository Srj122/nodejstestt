"use client";

import { twMerge } from "tailwind-merge";

import { IClassName } from "@/interface";
import { appStore, googlePlay } from "@/lib/assets";
import Image from "next/image";
import Link from "next/link";
import { FC } from "react";

export const AppDownload: FC<IClassName> = ({ className }) => (
  <section
    className={twMerge("flex justify-center items-center gap-2.5", className)}
  >
    <Link href="#">
      <Image src={appStore} className="w-full md:w-36" alt="" />
    </Link>
    <Link href="#">
      <Image src={googlePlay} className="w-full md:w-36" alt="" />
    </Link>
  </section>
);
