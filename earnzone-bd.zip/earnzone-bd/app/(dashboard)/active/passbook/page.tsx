"use client";

import { useState } from "react";

import { DataTable, Header, PageHeader } from "@/components";
import { useGetData } from "@/hooks";
import { INavItem, IUser, IWithdrawal } from "@/interface";
import { BackButton, Button, Title } from "@/universal";
import { AiOutlineHome } from "react-icons/ai";

const navData: INavItem[] = [
  {
    label: <BackButton className="text-2xl" />,
    link: "/active/user/profile",
  },
  {
    label: <AiOutlineHome className="text-2xl" />,
    link: "/active",
  },
];

export type IDataType = "credit" | "debit";

const Passbook = () => {
  const [passbookData, setPassbookData] = useState<IUser[] | null>(null);
  const [passbookDebitData, setPassbookDebitData] = useState<
    IWithdrawal[] | null
  >(null);
  const [dataType, setDataType] = useState<IDataType>("credit");

  useGetData("/passbook", setPassbookData, true);
  useGetData("/passbook/debit", setPassbookDebitData, true);

  return (
    <>
      <Header navData={navData} />
      <PageHeader title="Passbook" notice="Last 3 Month Outbound" />
      <div className="flex justify-center gap-4 py-6">
        <Button
          onClick={() => setDataType("credit")}
          variant={dataType === "credit" ? "primary" : "secondary"}
        >
          Credit History
        </Button>
        <Button
          onClick={() => setDataType("debit")}
          variant={dataType === "debit" ? "primary" : "secondary"}
        >
          Debit History
        </Button>
      </div>

      {passbookData === null ? (
        <Title variant="H4" className="text-center capitalize my-10">
          Loading... Please wait 🔃
        </Title>
      ) : dataType === "credit" && passbookData?.length !== 0 ? (
        <DataTable
          tableData={passbookData}
          tableHeaders={["No", "Date", "id", "Name", "amount", "description"]}
          dataProperties={[
            "createdAt",
            "studentId",
            "name",
            "amount",
            "description",
          ]}
        />
      ) : dataType === "debit" && passbookDebitData ? (
        <DataTable
          tableData={passbookDebitData}
          tableHeaders={["no", "Date", "amount", "method", "Number", "status"]}
          dataProperties={["createdAt", "amount", "method", "number", "status"]}
        />
      ) : (
        <Title variant="H3" className="text-center capitalize my-10">
          Passbook data not found 😒
        </Title>
      )}
    </>
  );
};

export default Passbook;
