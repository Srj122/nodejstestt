"use client";

import { FC } from "react";
import { twMerge } from "tailwind-merge";

import { IButton } from "@/interface";

export const Button: FC<IButton> = ({
  children,
  className,
  onClick,
  type = "button",
  disabled,
  variant = "primary",
}) => {
  const btnVariant =
    (variant === "primary" &&
      "bg-gradient-to-r hover:from-[#31c38e] hover:to-[#3f85f6] from-[#e64790] to-[#c37606] px-7 py-3 rounded") ||
    (variant === "secondary" &&
      "bg-gradient-to-r from-[#31c38e] to-[#3f85f6] hover:from-[#e64790] hover:to-[#c37606] px-7 py-3 rounded-md") ||
    (variant === "accent" &&
      "px-2 py-1 bg-secondary hover:bg-primary rounded font-medium");

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={twMerge(
        "text-sm text-white text-center font-sora font-semibold transition-all delay-150",
        btnVariant,
        className
      )}
    >
      {children}
    </button>
  );
};
