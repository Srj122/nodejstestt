"use client";

export * from "./About";
export * from "./Hero";
export * from "./OurServices";
export * from "./FAQ";
export * from "./PopularCourses";
export * from "./UpComingEvents";
