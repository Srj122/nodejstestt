<h1 align="center">Earn zone bd</h1>

### Earn zone bd Live site [Vercel 🔗](https://fake-earn-bd.vercel.app/) - [Live 🔗]()

## User List

**_Password of all accounts is `11223`_**

### Phone Number:-

1. Admin: 01512345670
2. Senior Team Leader: 01512345673
3. Team Leader: 01512345671
4. Controller: 01512345674
5. Consultant: 01512345675
6. Checker: 01512345676
7. Trainer: 01512345678

#### Teacher List:-

1. Learning All Quran - 01712345670
2. Photo Editing class - 01712345671
3. Video Editing class - 01712345672
4. Lead Generation Class - 01712345673
5. Data Entry class - 01712345674
6. Graphic Design Class - 01712345675
7. YouTube Content Creating - 01712345676
8. Digital Marketing Class - 01712345677
9. Social Marketing - 01712345678
10. Spoken English (special) - 01712345679
