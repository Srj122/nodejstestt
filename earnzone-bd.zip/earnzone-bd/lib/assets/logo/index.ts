"use client";

import logo from "./logo.png";

export { logo };
