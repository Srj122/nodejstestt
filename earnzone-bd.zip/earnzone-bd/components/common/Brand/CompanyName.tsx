"use client";

import { FC } from "react";

export const CompanyName: FC = () => <span>Earn Zone BD</span>;
