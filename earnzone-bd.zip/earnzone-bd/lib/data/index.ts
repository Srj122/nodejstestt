export * from "./common";
export * from "./courses";
export * from "./home";
export * from "./privacyPolicy";
