import { ICardData, IEventsData, IFaqList } from "@/interface";
import { course1, course2, course3, serviceImg1, serviceImg2 } from "../assets";

export const servicesData: ICardData[] = [
  {
    title: "Online Health Consultation with MBBS or BHMS or BDS Doctor",
    fees: "100 (INR)",
    thumbnail: serviceImg1,
    href: "/",
  },
  {
    title: "Online Astrology Consultation",
    fees: "1100 (INR)",
    thumbnail: serviceImg2,
    href: "/",
  },
];

export const courseInfoData: ICardData[] = [
  {
    title: "Digital Marketing",
    fees: "Fees - 1300 (INR) (fluctuate over time)",
    thumbnail: course1,
    href: "/",
  },
  {
    title: "Basic Share market Knowledge",
    fees: "Fees - 1000 (INR) for India",
    thumbnail: course2,
    href: "/",
  },
  {
    title: "Spoken English Courses",
    fees: "Fees - 1000 (INR) for India",
    thumbnail: course3,
    href: "/",
  },
];

export const eventsData: IEventsData[] = [
  {
    date: "🥇",
    title:
      "We hosted free training sessions covering various topics such as digital marketing, graphic design, and Facebook marketing.",
  },
  {
    date: "🥈",
    title:
      "We conducted free training sessions focusing on imparting fundamental knowledge of the stock market.",
  },
];

export const faqsList: IFaqList[] = [
  {
    q: "What is Earnzone-bd E-learning platform?",
    a: "Earnzone-bd is a comprehensive online platform offering diverse educational resources and courses for learners of all ages. Besides it, a learner can earn money by doing some easy works in our platform in their free times",
  },
  {
    q: "Do we need to pay any admission fee to join this company?",
    a: "After your ID activation we have to pay service charges from your income and before ID activation, we need to buy some access to activate your ID, 'like google access'. For that you have to pay access fee, of course it’s not admission fee.",
  },
  {
    q: "Can we do this from the comfort of our home ( work from home )?",
    a: "Yes, You can do all the facilities that we provide to the students by sitting at home or staying at your convenient place with your mobile phone or computer.",
  },
  {
    q: "What kind of documents and gadgets do we need to do this work?",
    a: "As this is an online Learning and Earning platform, We don't take any documents or gadgets for your convenience, just provide some general information about you, like 'Name, Gmail, WhatsApp number'.",
  },

  {
    q: "Is this a part-time or a full-time Work?",
    a: "First of all it is a part-time work, but from here you can develop yourself and take your life to the peak of improvement very easily, for that our platform is working continuously. But many are working here as full time works.",
  },
];
