"use client";

import { IChildren } from "@/interface";
import { FC } from "react";

export const Card: FC<IChildren> = ({ children }) => <div>{children}</div>;
