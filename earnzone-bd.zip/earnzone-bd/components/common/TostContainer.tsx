"use client";

import { FC, useState } from "react";
import { Tost } from ".";

import { useCurrentUser } from "@/hooks";
import { signIn } from "next-auth/react";

export const TostContainer: FC = () => {
  const [tost1, setTost1] = useState(true);
  const [tost2, setTost2] = useState(true);
  const user = useCurrentUser(true);

  return (
    <div className="space-y-3.5 w-fit mx-auto px-2.5 mt-3.5">
      {tost1 && (
        <Tost
          label="Don't share your phone number or password with anyone"
          btnText="Ok"
          onClick={() => setTost1(false)}
        />
      )}
      {tost2 && user?.role === "active" && (
        <Tost
          label="We are active student"
          btnText="Ok"
          onClick={() => setTost2(false)}
        />
      )}
      <Tost
        label="Follow our Whatsapp Channel for Updates 📰"
        btnText="Follow"
      />
      {user && !user.isVerified && (
        <Tost
          label="Verify Email Address"
          btnText="verify"
          onClick={() => signIn("google")}
        />
      )}
    </div>
  );
};
