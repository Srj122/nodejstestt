"use client";

import { updateData } from "@/hooks";
import { ISendWish, IWaDeepLink, IWaShareLink } from "@/interface";
import { Button } from "@/universal";
import { openWhatsappChat } from "@/utils";
import { FC } from "react";
import { FaShareSquare } from "react-icons/fa";

export const WhatsAppLink: FC<IWaDeepLink> = ({
  phoneNo,
  btnText,
  message,
  groupLink,
}) => {
  return (
    <Button
      variant="secondary"
      onClick={() => openWhatsappChat(phoneNo, message, groupLink)}
    >
      {btnText}
    </Button>
  );
};

export const SendWishMessage: FC<ISendWish> = ({
  phoneNo,
  btnText,
  message,
  groupLink,
  data,
  userId,
}) => {
  const handleSendWish = () => {
    updateData(`/send-wish?id=${userId}`, {
      ...data,
    }).then(() => openWhatsappChat(phoneNo, message, groupLink));
  };
  return (
    <Button variant="secondary" onClick={handleSendWish}>
      {btnText}
    </Button>
  );
};

export const ShareReferLink: FC<IWaShareLink> = ({
  phoneNo,
  btnText,
  groupLink,
  userId,
}) => {
  const handleSendWish = () => {
    const referalLink = `https://earnzonebd.com/signup?referral=${userId}`;
    openWhatsappChat(phoneNo, referalLink, groupLink);
  };
  return (
    <Button
      variant="secondary"
      onClick={handleSendWish}
      className="flex gap-2 justify-center items-center md:py-2 w-full"
    >
      {btnText}
      <FaShareSquare className="" />
    </Button>
  );
};
