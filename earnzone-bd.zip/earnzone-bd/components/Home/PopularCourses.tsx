"use client";

import { courses } from "@/lib/data";
import { Container, Title } from "@/universal";
import { FC } from "react";
import { ImageCard } from "..";

export const PopularCourses: FC = () => {
  return (
    <div className="bg-[#442e9e] w-full">
      <Container className="text-white pt-10 pb-2">
        <Title variant="H1" className="mb-5 text-center capitalize">
          Popular Courses
        </Title>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 pb-14 md:pb-10">
          {[courses[0], courses[9], courses[5], courses[4]].map(
            (course, idx) => (
              <ImageCard
                key={idx}
                fees={course.price}
                href={course.href}
                thumbnail={course.img}
                title={course.title}
              />
            )
          )}
        </div>
      </Container>
    </div>
  );
};
