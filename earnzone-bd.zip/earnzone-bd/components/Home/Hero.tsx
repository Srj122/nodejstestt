"use client";

import {
  avatar,
  banner,
  banner1,
  banner2,
  banner3,
  banner4,
  books,
  logo,
  time,
} from "@/lib/assets";
import {
  BackgroundImg,
  Button,
  CommonText,
  Container,
  LinkButton,
  Title,
} from "@/universal";
import { signOut, useSession } from "next-auth/react";
import Image from "next/image";
import Link from "next/link";
import { FC, useEffect, useState } from "react";

export const Hero: FC = () => {
  const { data: sessions } = useSession();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentSlide, setCurrentSlide] = useState(banner);

  const slides = [banner, banner1, banner2, banner3, banner4];

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
    }, 7000);

    return () => clearInterval(intervalId);
  }, [slides.length]);

  useEffect(() => {
    slides.map(
      (slide, index) => index === currentIndex && setCurrentSlide(slide)
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentIndex]);

  return (
    <BackgroundImg
      img={currentSlide}
      className="h-auto pb-5 lg:pb-0 lg:h-auto lg:min-h-screen overflow-visible"
      overflow
    >
      <Container className="lg:min-h-screen flex flex-col justify-center items-start pt-5 lg:pt-0 relative">
        <figure>
          <Image
            src={logo}
            width={300}
            height={150}
            className="2xl:-ml-20 pt-2.5"
            alt=""
          />
        </figure>

        <div className="flex flex-col justify-center items-start gap-4 mt-1.5 md:mb-4 lg:mb-24 xl:mb-8">
          <Title
            variant="H1"
            className="text-white text-3xl md:text-4xl font-bold text-left max-w-3xl"
          >
            WELCOME TO <br className="sm:hidden" /> earnzone-bd
            <br className="sm:hidden md:flex lg:hidden" /> E-LEARNING PLATFORM
          </Title>
          <CommonText className="max-w-[640px] text-white text-base lg:text-xl">
            You will need a good smart phone and good internet connection to
            work here. It is a very easy process and you can learn this process
            in your own mother tongue and earn from our community by doing
            courses, services and other works.
          </CommonText>

          <div className="w-fit space-x-1.5">
            {sessions?.user ? (
              <>
                <LinkButton variant="secondary" href="/active">
                  Dashboard
                </LinkButton>
                <Button onClick={() => signOut()}>SignOut</Button>
              </>
            ) : (
              <div className="space-y-1.5">
                <div className="space-x-1.5">
                  <LinkButton href="/login">Login</LinkButton>
                  <LinkButton href="/signup">SignUp</LinkButton>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <LinkButton href="/">Visitour store</LinkButton>
                  <LinkButton href="/">Visit our official group</LinkButton>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="w-full min-h-[100px]" />
      </Container>

      <div className="absolute -bottom-[340px]  md:-bottom-20 w-full">
        <Container className="flex flex-col md:flex-row justify-center items-center gap-5 lg:gap-14">
          <Link
            href="/courses"
            className="bg-gradient-to-r from-[#0b0e4a] to-[#412d9b] w-full lg:w-96 h-28 lg:h-40 flex justify-start items-center gap-10 text-white p-[30px] rounded-xl"
          >
            <Image
              src={books}
              className="w-[50px] h-[50px] lg:w-[104px] lg:h-[107px]"
              alt=""
            />
            <p className="text-2xl">
              20+ <br className="hidden lg:block" /> courses
            </p>
          </Link>
          <div className="bg-gradient-to-r from-[#0b0e4a] to-[#412d9b] w-full lg:w-96 h-28 lg:h-40 flex justify-start items-center gap-10 text-white p-[30px] rounded-xl">
            <Image
              src={avatar}
              className="w-[50px] h-[50px] lg:w-[104px] lg:h-[107px]"
              alt=""
            />
            <p className="text-2xl">
              Expert <br className="hidden lg:block" />
              mentors
            </p>
          </div>
          <div className="bg-gradient-to-r from-[#0b0e4a] to-[#412d9b] w-full lg:w-96 h-28 lg:h-40 flex justify-start items-center gap-10 text-white p-[30px] rounded-xl">
            <Image
              src={time}
              className="w-[50px] h-[50px] lg:w-[104px] lg:h-[107px]"
              alt=""
            />
            <p className="text-2xl">
              Life time <br className="hidden lg:block" />
              access
            </p>
          </div>
        </Container>
      </div>
    </BackgroundImg>
  );
};
