import avatarProfile from "./avater.png";
import bell from "./bell.gif";
import popular1 from "./popular-1.jpg";
import popular2 from "./popular-2.jpg";
import popular3 from "./popular-3.jpg";
import popular4 from "./popular-4.jpg";
import uploadImg from "./uploadImg.jpg";

export {
  avatarProfile,
  bell,
  popular1,
  popular2,
  popular3,
  popular4,
  uploadImg,
};
