import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { FC } from "react";
import { ToastContainer } from "react-toastify";

import { AuthProvider } from "@/components";
import { IChildren } from "@/interface";

import "@/styles/globals.css";
import "react-toastify/dist/ReactToastify.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Earn Zone BD",
  description:
    "It is an Bangladeshi trusted online platform. It is a learning and earning process by using your valuable free time at home through your smart phone only It is a very easy process and you can learn this process on your own mother tongue and you can earn from our community with selling some Courses Services or product also. Here you make your career smoothly.",
  openGraph: {
    title: "Earn Zone BD",
    description:
      "It is an Bangladeshi trusted online platform. It is a learning and earning process by using your valuable free time at home through your smart phone only It is a very easy process and you can learn this process on your own mother tongue and you can earn from our community with selling some Courses Services or product also. Here you make your career smoothly.",
    url: "https://www.earnzonebd.com/logo-life_change_bd.png",
    siteName: "Earn Zone BD",
    images: [
      {
        url: "https://www.earnzonebd.com/logo-life_change_bd.png",
        width: 600,
        height: 300,
        alt: "WELCOME TO Earn Zone BD E-LEARNING PLATFORM",
      },
      {
        url: "https://www.earnzonebd.com/logo-life_change_bd_original.png",
        width: 600,
        height: 600,
        alt: "WELCOME TO Earn Zone BD E-LEARNING PLATFORM",
      },
    ],
    locale: "en_US",
    type: "website",
  },
};

const RootLayout: FC<IChildren> = ({ children }) => (
  <html lang="en">
    <body className={inter.className}>
      <AuthProvider>
        {children}
        <ToastContainer
          position="bottom-center"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover={false}
          theme="light"
        />
      </AuthProvider>
    </body>
  </html>
);

export default RootLayout;
