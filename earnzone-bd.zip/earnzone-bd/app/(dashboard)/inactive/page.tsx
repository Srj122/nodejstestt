"use client";

import { Header, TostContainer } from "@/components";
import {
  ActivationPoint,
  Footer,
  ImageUploadSection,
  Meeting,
  Support,
} from "@/components/User/Inactive";
import { INavItem } from "@/interface";
import { AiOutlineHome } from "react-icons/ai";

const navData: INavItem[] = [
  {
    label: <AiOutlineHome className="text-2xl" />,
    link: "/active",
  },
  {
    label: "Profile",
    link: "/inactive/profile",
  },
  {
    label: "Photo Zone",
    link: "/photo-zone",
  },
];

const Inactive = () => (
  <>
    <Header navData={navData} />
    <TostContainer />
    <ImageUploadSection />
    <Support />
    <section className="bg-black">
      <Meeting />
      <ActivationPoint />
      <Footer />
    </section>
  </>
);

export default Inactive;
