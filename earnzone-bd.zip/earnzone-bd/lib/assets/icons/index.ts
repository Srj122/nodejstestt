import googleMeet from "./Google_Meet_icon.png";
import appStore from "./appstore.svg";
import avatar from "./avatar.png";
import books from "./books.png";
import bulletList from "./bullet-list.svg";
import close from "./close.svg";
import facebook from "./facebook.png";
import globe from "./globe.png";
import googlePlay from "./googlePlay.svg";
import group from "./groupdiscuss.png";
import helping from "./helpinghand.png";
import pinterest from "./pinterest.svg";
import plus from "./plus.png";
import time from "./time.png";
import twitter from "./twitter.svg";
import whatsapp from "./whatsapp.png";
import youtube from "./youtube.png";

export {
  appStore,
  avatar,
  books,
  bulletList,
  close,
  facebook,
  globe,
  googleMeet,
  googlePlay,
  group,
  helping,
  pinterest,
  plus,
  time,
  twitter,
  whatsapp,
  youtube,
};
