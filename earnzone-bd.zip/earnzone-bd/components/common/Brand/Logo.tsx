"use client";

import Image from "next/image";
import Link from "next/link";
import { FC } from "react";

import { logo } from "@/lib/assets";

export const Logo: FC = () => (
  <Link href="/">
    <Image src={logo} className="w-[45px] h-[45px]" alt="Earn Zone BD" />
  </Link>
);
