"use client";

import { IBackgroundImage } from "@/interface";
import Image from "next/image";
import { FC } from "react";
import { twMerge } from "tailwind-merge";

export const BackgroundImg: FC<IBackgroundImage> = ({
  children,
  img,
  mobImg,
  className,
  overflow,
}) => (
  <section
    className={twMerge(
      `relative w-full ${overflow && "overflow-hidden"}`,
      className
    )}
  >
    <div className={`absolute w-full inset-0`}>
      <Image
        src={img}
        className={`w-full object-cover`}
        alt="background image"
        fill
      />
      {mobImg && (
        <Image
          src={mobImg}
          className="w-full block md:hidden"
          alt="background image"
          fill
        />
      )}
    </div>

    <div className="relative z-10">{children}</div>
  </section>
);
